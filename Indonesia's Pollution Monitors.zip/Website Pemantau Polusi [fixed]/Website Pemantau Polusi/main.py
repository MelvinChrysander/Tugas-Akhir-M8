import folium
import time
import requests
from bs4 import BeautifulSoup
from flask import Flask, render_template
from folium import Map, Circle
app = Flask(__name__)
interval = 600
last_tick = 0
warna_kota_list = {}
first_half = []
second_half = []



def get_data():
    global first_half, second_half
    
    nama_kota_set = set()
    nama_kota_list = []
    nilai_polusi_list = []
    koordinat_peta = []
    
    #Data Polusi Samarinda
    page_smd = requests.get("https://www.iqair.com/indonesia/east-kalimantan/samarinda")
    after_bs_smd= BeautifulSoup(page_smd.text, "html.parser")
    find_data_smd = after_bs_smd.find_all("div", class_='container content__wrapper')
    
    for div in find_data_smd:
        p_elements_smd = div.find_all("p", class_='aqi-value__value')

        for p in p_elements_smd:
            if "*" in p.text:
                hasil_smd = p.text.replace('*', '')
            else:
                hasil_smd = p.text
            nama_kota_set.add("Kota Samarinda, Kalimantan Timur")
            nama_kota_list.append("Kota Samarinda, Kalimantan Timur")
            nilai_polusi_list.append(hasil_smd)
    
    #Data Polusi pontianak
    page_ptk = requests.get("https://www.iqair.com/indonesia/west-kalimantan/pontianak")
    after_bs_ptk= BeautifulSoup(page_ptk.text, "html.parser")
    find_data_ptk = after_bs_ptk.find_all("div", class_='container content__wrapper')
    
    for div in find_data_ptk:
        p_elements_ptk = div.find_all("p", class_='aqi-value__value')

        for p in p_elements_ptk:
            if "*" in p.text:
                hasil_ptk = p.text.replace('*', '')
            else:
                hasil_ptk = p.text
            nama_kota_set.add("Kota Pontianak, Kalimantan Barat")
            nama_kota_list.append("Kota Pontianak, Kalimantan Barat")
            nilai_polusi_list.append(hasil_ptk)
    
    #Data Polusi Makassar
    page_mks = requests.get("https://www.iqair.com/indonesia/southeast-sulawesi/palu")
    after_bs_mks= BeautifulSoup(page_mks.text, "html.parser")
    find_data_mks = after_bs_mks.find_all("div", class_='container content__wrapper')
    
    for div in find_data_mks:
        p_elements_mks = div.find_all("p", class_='aqi-value__value')

        for p in p_elements_mks:
            if "*" in p.text:
                hasil_mks = p.text.replace('*', '')
            else:
                hasil_mks = p.text
            nama_kota_set.add("Kota Makassar, Sulawesi Selatan")
            nama_kota_list.append("Kota Makassar, Sulawesi Selatan")
            nilai_polusi_list.append(hasil_mks)
    
    
    #Data Polusi palu
    page_pl = requests.get("https://www.iqair.com/indonesia/southeast-sulawesi/palu")
    after_bs_pl= BeautifulSoup(page_pl.text, "html.parser")
    find_data_pl = after_bs_pl.find_all("div", class_='container content__wrapper')
    
    for div in find_data_pl:
        p_elements_pl = div.find_all("p", class_='aqi-value__value')

        for p in p_elements_pl:
            if "*" in p.text:
                hasil_pl = p.text.replace('*', '')
            else:
                hasil_pl = p.text
            nama_kota_set.add("Kota Palu, Sulawesi Tengah")
            nama_kota_list.append("Kota Palu, Sulawesi Tengah")
            nilai_polusi_list.append(hasil_pl)
    
    #Data Polusi Denpasar
    page_dps = requests.get("https://www.iqair.com/indonesia/bali/denpasar")
    after_bs_dps= BeautifulSoup(page_dps.text, "html.parser")
    find_data_dps = after_bs_dps.find_all("div", class_='container content__wrapper')
    
    for div in find_data_dps:
        p_elements_dps = div.find_all("p", class_='aqi-value__value')

        for p in p_elements_dps:
            if "*" in p.text:
                hasil_dps = p.text.replace('*', '')
            else:
                hasil_dps = p.text
            nama_kota_set.add("Kota Denpasar, Provinsi Bali")
            nama_kota_list.append("Kota Denpasar, Provinsi Bali")
            nilai_polusi_list.append(hasil_dps)
    
    #Data Polusi Semarang
    page_smr = requests.get("https://www.iqair.com/indonesia/central-java/semarang")
    after_bs_smr = BeautifulSoup(page_smr.text, "html.parser")
    find_data_smr = after_bs_smr.find_all("div", class_='container content__wrapper')
    
    for div in find_data_smr:
        p_elements_smr = div.find_all("p", class_='aqi-value__value')

        for p in p_elements_smr:
            if "*" in p.text:
                hasil_smr = p.text.replace('*', '')
            else:
                hasil_smr = p.text
            nama_kota_set.add("Kota Semarang, Jawa Tengah")
            nama_kota_list.append("Kota Semarang, Jawa Tengah")
            nilai_polusi_list.append(hasil_smr)
    
    #Data Polusi Jambi
    page_jmb = requests.get("https://www.iqair.com/indonesia/jambi/jambi-city")
    after_bs_jmb = BeautifulSoup(page_jmb.text, "html.parser")
    find_data_jmb = after_bs_jmb.find_all("div", class_='container content__wrapper')
    
    for div in find_data_jmb:
        p_elements_jmb = div.find_all("p", class_='aqi-value__value')

        for p in p_elements_jmb:
            if "*" in p.text:
                hasil_jmb = p.text.replace('*', '')
            else:
                hasil_jmb = p.text
            nama_kota_set.add("Kota Jambi, Provinsi Jambi")
            nama_kota_list.append("Kota Jambi, Provinsi Jambi")
            nilai_polusi_list.append(hasil_jmb)
            
    #Data Polusi Aceh
    page_ach = requests.get("https://www.iqair.com/indonesia/aceh/banda-aceh")
    after_bs_ach = BeautifulSoup(page_ach.text, "html.parser")
    find_data_ach = after_bs_ach.find_all("div", class_='container content__wrapper')
    
    for div in find_data_ach:
        p_elements_ach = div.find_all("p", class_='aqi-value__value')

        for p in p_elements_ach:
            if "*" in p.text:
                hasil_ach = p.text.replace('*', '')
            else:
                hasil_ach = p.text
            nama_kota_set.add("Banda Aceh, Nanggroe Aceh Darussalam")
            nama_kota_list.append("Banda Aceh, Nanggroe Aceh Darussalam")
            nilai_polusi_list.append(hasil_ach)
            
    #Data Polusi Banjarmasin
    page_bjm = requests.get("https://www.iqair.com/indonesia/south-kalimantan/banjarmasin")
    after_bs_bjm = BeautifulSoup(page_bjm.text, "html.parser")
    find_data_bjm = after_bs_bjm.find_all("div", class_='container content__wrapper')
    
    for div in find_data_bjm:
        p_elements_bjm = div.find_all("p", class_='aqi-value__value')

        for p in p_elements_bjm:
            if "*" in p.text:
                hasil_bjm = p.text.replace('*', '')
            else:
                hasil_bjm = p.text
            nama_kota_set.add("Kota Banjarmasin, Kalimantan Selatan")
            nama_kota_list.append("Kota Banjarmasin, Kalimantan Selatan")
            nilai_polusi_list.append(hasil_bjm)
            
            
    #Data Polusi Surabya
    page_sby = requests.get("https://www.iqair.com/id/indonesia/east-java/surabaya")
    after_bs_sby = BeautifulSoup(page_sby.text, "html.parser")
    find_data_sby = after_bs_sby.find_all("div", class_='container content__wrapper')
    
    for div in find_data_sby:
        p_elements_sby = div.find_all("p", class_='aqi-value__value')

        for p in p_elements_sby:
            if "*" in p.text:
                hasil_sby = p.text.replace('*', '')
            else:
                hasil_sby = p.text
            nama_kota_set.add("Kota Surabaya, Jawa Timur")
            nama_kota_list.append("Kota Surabaya, Jawa Timur")
            nilai_polusi_list.append(hasil_sby)
                        
    #Mengambil data polusi 
    url = "https://www.iqair.com/id/indonesia"
    response = requests.get(url)

    after_bs = BeautifulSoup(response.content, "html.parser")
    
    find_data = after_bs.find_all('tr', attrs={'_ngcontent-sc291':''})
    
    #-----------List Untuk Peta---------
    
    #Kota yang akan dikecualikan dan tidak masuk ke data_list
    kota_kecuali = ["Chad", "Iraq", "Pakistan", "Bahrain", "Bangladesh", "Burkina Faso", 
                    "Kuwait", "India", "Egypt", "Tajikistan", "Indonesia"]
    
    
    koordinat_kota = {
        "South Tangerang, Provinsi Banten": (-6.28862, 106.71789),
        "Kota Bandung, Jawa Barat": (-6.92222, 107.60694),
        "Jakarta, Jakarta": (-6.21462, 106.84513),
        "Kota Pekanbaru, Riau": (0.51667, 101.44167),
        "Kabupaten Serang, Provinsi Banten": (-6.11528, 106.15417),
        "Kota Bogor, Jawa Barat": (-6.59444, 106.78917),
        "Kota Denpasar, Provinsi Bali": (-8.65, 115.21667),
        "Kota Surabaya, Jawa Timur": (-7.2492, 112.7508),
        "Kota Medan, Daerah Tingkat I Sumatera Utara": (3.5952, 98.6722),
        "Palembang, Sumatera Selatan": (-2.9761, 104.7754),
        "Kota Banjarmasin, Kalimantan Selatan": (-3.31987, 114.59075),
        "Banda Aceh, Nanggroe Aceh Darussalam": (5.5577, 95.3222),
        "Kota Jambi, Provinsi Jambi":(-1.5, 103.0),
        "Kota Semarang, Jawa Tengah":(-6.9932, 110.4203),
        "Kota Palu, Sulawesi Tengah":(-0.8917, 119.8707),
        "Kota Makassar, Sulawesi Selatan":(-5.14, 119.4221),
        "Kota Pontianak, Kalimantan Barat":(-0.03109, 109.32199),
        "Kota Samarinda, Kalimantan Timur":(-0.48585, 117.1466)
    }
    
    for div in find_data:
        kota = div.find("a")
        polusi = div.find("p")

        if kota and polusi:
            nama_kota = kota.text.strip()
            nilai_polusi = polusi.text.strip()

            if nama_kota not in kota_kecuali and nama_kota not in nama_kota_set:
                koordinat = koordinat_kota.get(nama_kota)
                nama_kota_set.add(nama_kota)
                nama_kota_list.append(nama_kota)
                nilai_polusi_list.append(nilai_polusi)
                koordinat_peta.append(koordinat)

    def convert_to_int(pollution_value):
        cleaned_value = ''.join(char for char in pollution_value if char.isdigit())
        return int(cleaned_value) if cleaned_value else 0

    # Membuat data list dengan tuple (nama_kota, nilai_polusi)
    data_list = [(nama_kota, convert_to_int(nilai_polusi)) for nama_kota, nilai_polusi in zip(nama_kota_list, nilai_polusi_list)]

    # Membagi data list
    #--------------------------------
    
    
    # Membagi Dua
    data_list_sorted = sorted(data_list, key=lambda x: x[1], reverse=True)
    half_length = len(data_list_sorted) // 2
    first_half = data_list_sorted[:half_length]
    second_half = data_list_sorted[half_length:]
    
    # Inisialisasi peta
    m = folium.Map(location=[-0.974623, 117.583269], zoom_start=5)

    # Menambahkan layer tile dari OpenStreetMap
    folium.TileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', attr='OpenStreetMap').add_to(m)
    
    radius = 50000
    print("\nData setelah sorting:")
    for kota, polusi in data_list_sorted:
        print(f"{kota}: {polusi}")
     
    # Mengisi warna_kota_list dengan semua kota yang ada di nama_kota_list
    for nama_kota in data_list_sorted:
        if nama_kota not in warna_kota_list:
            warna_kota_list[nama_kota] = 'gray'
    
            
    #memberikan warna pada daftar dan peta
    for nama_kota, koordinat in koordinat_kota.items():
        if nama_kota in nama_kota_set:
            polusi_index = [i for i, (kota, _) in enumerate(data_list_sorted) if kota == nama_kota][0]
            polusi = data_list_sorted[polusi_index][1]
            
            if polusi <= 50:
                fill_color ="green"
                warna_kota = "#A8E05F"
            elif polusi <= 100:
                fill_color = "orange"
                warna_kota = "#FDD64B"
            elif polusi <= 150:
                fill_color ="red"
                warna_kota = "#FDD64B"
            elif polusi <=200:
                fill_color ="purple"
                warna_kota = "#A070B6"
            else:
                fill_color ="black"
                warna_kota = "grey"
                     
            warna_kota_list[nama_kota]= warna_kota
           
            
            Circle(
                location=koordinat,
                radius=radius,
                color=fill_color,
                weight=0,
                fill=True, 
                fill_color=fill_color,
                fill_opacity=0.5, 
                popup=nama_kota
                ).add_to(m)
        
    # Menampilkan peta
    m.save('static/map.html')
    return first_half, second_half, warna_kota_list


@app.route("/")
def Home():
    global last_tick, first_half, second_half, warna_kota_list

    if time.time() - last_tick > interval:
        first_half, second_half, warna_kota_list = get_data()
        last_tick = time.time()

    return render_template('index.html', first_half=first_half, second_half=second_half, warna_kota_list=warna_kota_list)


if __name__ == '__main__':
    app.run(debug=True, port=8000)